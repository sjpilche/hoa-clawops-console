# NSG CFO AI Suite Marketing System v2
Powered 100% by OpenClaw — local-first, near-zero cost

Version: 2.0 | February 18, 2026
Author: Steve Pilcher + Grok
Goal: 14-day Paid Pilot Blitz + full 6–12 month brand engine

Run with: openclaw run skills/* --local --human-gate

See MASTER_PLAN_V2.md for the complete strategy.
