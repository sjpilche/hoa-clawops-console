Week 1 (Blitz Launch)
Mon: Launch Spend Leak + Close pilots + Steve LinkedIn post
Tue–Fri: Outreach 50 emails/day (human reviewed)
Content: 2 Steve-voice posts + 1 proof artifact sample
