# Phase 0 Paid Pilot Offers

1. Spend Leak Finder (7 days) — $490 / $1,200 / $2,500
2. Close Acceleration (10 days) — $950 / $2,500 / $5,000
3. Get Paid Faster (AR) (14 days) — $750 / $1,500 / $3,000

Launch the first two immediately.
