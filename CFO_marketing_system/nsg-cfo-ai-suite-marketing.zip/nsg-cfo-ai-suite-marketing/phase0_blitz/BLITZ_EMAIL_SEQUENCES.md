Subject: Your AP leaks are probably costing you $X this month

Hi {{FirstName}},

Most companies your size using Sage 300/Vista have 3–8% spend leaks we can surface in one export.

I’m offering a 7-day Spend Leak Finder pilot for $490. Interested? Reply “yes”.

— Steve Pilcher
Former Construction CFO
