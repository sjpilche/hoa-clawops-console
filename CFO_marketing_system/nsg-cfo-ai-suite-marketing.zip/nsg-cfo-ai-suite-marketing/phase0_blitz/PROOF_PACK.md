# Proof Pack — 5–7% Cash Forecast Error (MAPE)

Claim: 5–7% Mean Absolute Percentage Error on 13-week rolling cash forecast
Period: 9 months (2024–2025) across 20 divisions
Inputs: AP/AR, job cost, payroll, bank feeds (anonymized)
Output: Weekly Excel + Trust Envelope™ (confidence % per line + audit trail)

Use on every landing page and LinkedIn post.
