# 4-Hour Launch Plan

Day 0: Run this script → open folder in VS Code → feed MASTER_PLAN_V2.md + skills/ to Claude
Day 1: Deploy 2 landing pages, run Lead Scout on 300 companies
Day 2: Launch pilots on LinkedIn + first outreach batch
Day 3–14: Deliver pilots → turn into case studies → roll into full brand engine
