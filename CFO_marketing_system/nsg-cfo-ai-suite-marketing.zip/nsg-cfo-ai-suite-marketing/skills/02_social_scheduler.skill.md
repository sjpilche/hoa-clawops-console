---
name: Social Scheduler
version: 1.0
description: Posts content to LinkedIn, X, forums at optimal times and monitors engagement.
triggers: [new_content_ready]
human_gate: false
local_llm_prompt: |
  Schedule Steve-voice posts for maximum CFO engagement. Use hashtags sparingly. Track replies.
