---
name: Analytics Monitor
version: 1.0
description: Pulls daily metrics and generates weekly reports.
local_llm_prompt: |
  Report pilot sign-ups, reply rates, and optimization suggestions.
